﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PointXYLine
{

    enum Axis
    {
        X,
        Y
    }

    public class Line  //直线插补坐标体
    {
        public Line() {

        }
        public Line(ref PointF startPoint, ref PointF endPoint) {
            StartPoint = startPoint;
            EndPoint = endPoint;
            PulseEqu = 0;
        }

        public static int ChangeLine(Line line, ref PointF startPoint, ref PointF endPoint) {
            line.StartPoint = startPoint;
            line.EndPoint = endPoint;
            return 0;
        }

        public static int ChangeLine(Line line, float x1, float y1, float x2, float y2) {
            line.StartPoint.X = x1;
            line.StartPoint.Y = y1;
            line.EndPoint.X = x2;
            line.EndPoint.Y = y2;
            return 0;
        }
        //重载，含脉冲当量
        public static int ChangeLine(Line line, float x1, float y1, float x2, float y2, float pulseEqu) {
            line.StartPoint.X = x1;
            line.StartPoint.Y = y1;
            line.EndPoint.X = x2;
            line.EndPoint.Y = y2;
            line.PulseEqu = pulseEqu;
            return 0;
        }

        public PointF StartPoint;
        public PointF EndPoint;

        public float PulseEqu; //脉冲当量
    };
    //坐标系类 
    class Coord
    {
        public int MaxX { get; set; }   //横坐标最大值
        public int MaxY { get; set; }   //纵坐标最大值
        public int LenX { get; set; }   
        public int LenY { get; set; }
        public PointF CenterPixel { get; set; } //panel中心点像素坐标，也是坐标轴原点

        public Panel M_Panel { get; set; }  //panel
        public int EdgeOffset { get; set; } //坐标系边缘相对panel边缘偏移量

        public int RadioX { get; set; }     //x轴上像素点位移与坐标轴位移比例
        public int RadioY { get; set; }     //y轴上像素点位移与坐标轴位移比例

        /// <summary>
        /// 坐标系构造函数
        /// </summary>
        /// <param name="panel"></param>传入panel
        /// <param name="maxX"></param>横坐标最大值
        /// <param name="maxY"></param>纵坐标最大值
        /// <param name="edgeOffset"></param>坐标系边缘相对panel边缘偏移量
        public Coord(Panel panel, int maxX, int maxY, int edgeOffset) {

            M_Panel = panel;
            this.MaxX = maxX;
            this.LenX = 2 * maxX;

            this.MaxY = maxY;
            this.LenY = 2 * maxY;
            this.EdgeOffset = edgeOffset;
            CenterPixel = new PointF() {
                X = panel.Width / 2,
                Y = panel.Height / 2
            };

            RadioX = (M_Panel.Width - 2 * EdgeOffset) / LenX;
            RadioY = (M_Panel.Height - 2 * EdgeOffset) / LenY;
        }

        /// <summary>
        /// 线的转换，将坐标点上的线转换为像素值上的线(实际的线)
        /// </summary>
        /// <param name="sourCdt"></param>内部为坐标点数值的Line类
        /// <returns></returns>  转换后为像素值的Line类
        private Line CdtConvert(Line sourCdt) {
            Line destCdt = new Line();

            //此处想成功执行 需要StartPoint和EndPoint不封装为属性
            //destCdt.StartPoint.X = (int)((0.5f * M_Panel.Width) + (RadioX * sourCdt.StartPoint.X));
            //destCdt.StartPoint.Y = (int)(0.5f * M_Panel.Height - RadioY * sourCdt.StartPoint.Y);
            //destCdt.EndPoint.X = (int)(0.5f * M_Panel.Width + RadioX * sourCdt.EndPoint.X);
            //destCdt.EndPoint.Y = (int)(0.5f * M_Panel.Height - RadioY * sourCdt.EndPoint.Y);

            destCdt.StartPoint.X = (int)(Convert_AToP(Axis.X, sourCdt.StartPoint.X));
            destCdt.StartPoint.Y = (int)(Convert_AToP(Axis.Y, sourCdt.StartPoint.Y));
            destCdt.EndPoint.X = (int)(Convert_AToP(Axis.X, sourCdt.EndPoint.X));
            destCdt.EndPoint.Y = (int)(Convert_AToP(Axis.Y, sourCdt.EndPoint.Y));

            return destCdt;
        }

        /// <summary>
        /// X或Y坐标的转换函数,将读取到的坐标转换为像素点坐标
        /// </summary>
        /// <param name="axis"></param> 选择点是X坐标或者Y坐标
        /// <param name="value"></param>  坐标值
        /// <returns></returns>
        public float Convert_AToP(Axis axis, float value) {
            switch (axis) {
                case Axis.X:
                    return 0.5f * M_Panel.Width + RadioX * value;
                case Axis.Y:
                    return 0.5f * M_Panel.Height - RadioY * value;
                default:
                    break;
            }
            return -1;
        }

        //画坐标系
        public void DrawCoord() {
            //清panel
            Clear_Panel();
            //画xy轴线
            DrawXYLine();

            //为轴线上添加刻度和标注
            DrawLable();

        }


        // 清panel为白色
        public void Clear_Panel() {
            Graphics g = M_Panel.CreateGraphics();
            g.Clear(Color.White);
            g.Dispose();
        }

        /// <summary>
        /// 画线line
        /// </summary>
        /// <param name="line"></param>
        public void DrawLine(Line line) {
            Line retls = CdtConvert(line);
            Graphics g = M_Panel.CreateGraphics();
            g.DrawLine(new Pen(Brushes.Black, 2), retls.StartPoint, retls.EndPoint);
            g.Dispose();
        }

        private void DrawXYLine() {
            //第一种方法实现坐标轴构建
            //PointF startPoint = new PointF(-MaxX, 0);
            //PointF endPoint = new PointF(MaxX, 0);
            //Line line = new Line(ref startPoint, ref endPoint);
            //DrawLine(line);

            //第二种方法实现坐标轴构建
            Line line = new Line();
            Line.ChangeLine(line, -MaxX, 0, MaxX, 0);
            DrawLine(line);

            Line.ChangeLine(line, 0, -MaxY, 0, MaxY);
            DrawLine(line);
        }

        /// <summary>
        /// 画坐标系标注
        /// </summary>
        private void DrawLable() {

            //x轴
            Graphics g = M_Panel.CreateGraphics();
            for (int i = -MaxX; i <= MaxX; i++) {
                PointF p1 = new PointF(Convert_AToP(Axis.X, i), CenterPixel.Y);
                PointF p2 = new PointF(Convert_AToP(Axis.X, i), CenterPixel.Y - 5);
                string lab = i.ToString();
                g.DrawLine(new Pen(Brushes.Black, 2), p1, p2);
                g.DrawString(lab, new Font("宋体", 8f), Brushes.Black,
                    new PointF(Convert_AToP(Axis.X, i), CenterPixel.Y + 2));
            }
            g.DrawString("X轴", new Font("宋体 ", 10f), Brushes.Black,
                new PointF(M_Panel.Width - EdgeOffset / 1.5f, CenterPixel.Y + 8));


            //y轴
            for (int i = -MaxY; i <= MaxY; i++) {
                PointF p1 = new PointF(CenterPixel.X, Convert_AToP(Axis.Y, i));
                PointF p2 = new PointF(CenterPixel.X + 5, Convert_AToP(Axis.Y, i));
                string lab = i.ToString();
                g.DrawLine(new Pen(Brushes.Black, 2), p1, p2);
                StringFormat drawFormat = new StringFormat() {
                    Alignment = StringAlignment.Far,
                    LineAlignment = StringAlignment.Center
                };
                if (i != 0) {
                    g.DrawString(lab, new Font("宋体", 8f), Brushes.Black,
                         new PointF(CenterPixel.X - 2, Convert_AToP(Axis.Y, i)), drawFormat);
                }
            }
            g.DrawString("Y轴", new Font("宋体 ", 10f), Brushes.Black,
                new PointF(CenterPixel.X - 2, EdgeOffset / 2f));

            g.Dispose();
        }
    }
}
