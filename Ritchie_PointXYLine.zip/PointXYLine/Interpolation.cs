﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PointXYLine
{
    class Interpolation
    {
        public static Coord M_Coord;

        static Interpolation() {
            M_Coord = null;
        }

        public static void Line_Interpolation(Coord coord, Line line) { //直线插补

            M_Coord = coord;
            coord.DrawLine(line);          
        }
         
        public static void Arc_Interpolation() {   //圆弧插补
               
        }
    }
}

