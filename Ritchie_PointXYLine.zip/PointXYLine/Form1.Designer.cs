﻿namespace PointXYLine
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.pan = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.X_Sat = new System.Windows.Forms.TextBox();
            this.X_Tgt = new System.Windows.Forms.TextBox();
            this.Y_Sat = new System.Windows.Forms.TextBox();
            this.Y_Tgt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkLine = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pulseEqn = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // pan
            // 
            this.pan.Location = new System.Drawing.Point(16, 15);
            this.pan.Margin = new System.Windows.Forms.Padding(4);
            this.pan.Name = "pan";
            this.pan.Size = new System.Drawing.Size(853, 600);
            this.pan.TabIndex = 0;
            this.pan.Paint += new System.Windows.Forms.PaintEventHandler(this.Pan_Paint);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1005, 530);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 29);
            this.button1.TabIndex = 1;
            this.button1.Text = "开始绘制";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1003, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "请输入两点坐标";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(905, 96);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "第一点：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(905, 165);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "第二点：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1003, 61);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "X坐标";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1109, 61);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Y坐标";
            // 
            // X_Sat
            // 
            this.X_Sat.Location = new System.Drawing.Point(1005, 92);
            this.X_Sat.Margin = new System.Windows.Forms.Padding(4);
            this.X_Sat.Name = "X_Sat";
            this.X_Sat.Size = new System.Drawing.Size(52, 25);
            this.X_Sat.TabIndex = 8;
            this.X_Sat.Text = "0";
            // 
            // X_Tgt
            // 
            this.X_Tgt.Location = new System.Drawing.Point(1005, 161);
            this.X_Tgt.Margin = new System.Windows.Forms.Padding(4);
            this.X_Tgt.Name = "X_Tgt";
            this.X_Tgt.Size = new System.Drawing.Size(52, 25);
            this.X_Tgt.TabIndex = 9;
            this.X_Tgt.Text = "5";
            // 
            // Y_Sat
            // 
            this.Y_Sat.Location = new System.Drawing.Point(1103, 92);
            this.Y_Sat.Margin = new System.Windows.Forms.Padding(4);
            this.Y_Sat.Name = "Y_Sat";
            this.Y_Sat.Size = new System.Drawing.Size(52, 25);
            this.Y_Sat.TabIndex = 10;
            this.Y_Sat.Text = "0";
            // 
            // Y_Tgt
            // 
            this.Y_Tgt.Location = new System.Drawing.Point(1103, 161);
            this.Y_Tgt.Margin = new System.Windows.Forms.Padding(4);
            this.Y_Tgt.Name = "Y_Tgt";
            this.Y_Tgt.Size = new System.Drawing.Size(52, 25);
            this.Y_Tgt.TabIndex = 11;
            this.Y_Tgt.Text = "5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1005, 298);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "请选择插补类型";
            // 
            // checkLine
            // 
            this.checkLine.AutoSize = true;
            this.checkLine.Checked = true;
            this.checkLine.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkLine.Location = new System.Drawing.Point(1005, 351);
            this.checkLine.Margin = new System.Windows.Forms.Padding(4);
            this.checkLine.Name = "checkLine";
            this.checkLine.Size = new System.Drawing.Size(89, 19);
            this.checkLine.TabIndex = 13;
            this.checkLine.Text = "直线插补";
            this.checkLine.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(908, 229);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "脉冲量：";
            // 
            // pulseEqn
            // 
            this.pulseEqn.Location = new System.Drawing.Point(1005, 229);
            this.pulseEqn.Margin = new System.Windows.Forms.Padding(4);
            this.pulseEqn.Name = "pulseEqn";
            this.pulseEqn.Size = new System.Drawing.Size(132, 25);
            this.pulseEqn.TabIndex = 16;
            this.pulseEqn.Text = "1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 701);
            this.Controls.Add(this.pulseEqn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkLine);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Y_Tgt);
            this.Controls.Add(this.Y_Sat);
            this.Controls.Add(this.X_Tgt);
            this.Controls.Add(this.X_Sat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pan);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pan;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox X_Sat;
        private System.Windows.Forms.TextBox X_Tgt;
        private System.Windows.Forms.TextBox Y_Sat;
        private System.Windows.Forms.TextBox Y_Tgt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkLine;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox pulseEqn;


    }
}

