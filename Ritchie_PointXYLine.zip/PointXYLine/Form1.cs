﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace PointXYLine
{
    public partial class Form1 : Form
    {
        public Form1() {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e) {
            //创建坐标系实例
            Coord coord = new Coord(pan, 10, 10, 40);

            //画坐标系
            coord.DrawCoord();

            if (checkLine.Checked) {
                //画线
                Line line = new Line();
                Line.ChangeLine(line, (float)Convert.ToDouble(X_Sat.Text), (float)Convert.ToDouble(Y_Sat.Text),
                     (float)Convert.ToDouble(X_Tgt.Text), (float)Convert.ToDouble(Y_Tgt.Text));

                Interpolation.Line_Interpolation(coord, line);
            }
        }


        private void Pan_Paint(object sender, PaintEventArgs e) {
            //创建坐标系实例
            Coord coord = new Coord(pan, 10, 10, 40);

            //画坐标系
            coord.DrawCoord();
        }


        private void Form1_Load(object sender, EventArgs e) {

        }
    }
}
